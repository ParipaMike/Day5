package by.javatr.task1.paripa.by.finals;

public class Const {

	public static final int SIZE = 10;
	public static final int FIRST = 0;

	private Const() {

	}

}
